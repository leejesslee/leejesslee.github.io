using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PathInitializer {

	bool[,] mLevel;

	public PathInitializer(bool[,] map){
		mLevel = map;
	}

	public Queue<Vector2> buildPath(Vector2 start, Vector2 destination){ 
		int STOPIT = 0;
		Queue<Vector2> finalPath = new Queue<Vector2> ();
		finalPath.Enqueue(start);
		Vector2 current = start;
		Vector2 direction = Vector2.zero;
		Vector2 next;
		bool skip = false;
		bool rand = false;
		//bool[] randVec = new bool[8];
		while (true) {
			if(!rand){
				direction = new Vector2(Mathf.RoundToInt(destination.x - current.x),Mathf.RoundToInt(destination.y - current.y)).normalized;
				direction = new Vector2 (Mathf.RoundToInt(direction.x), Mathf.RoundToInt(direction.y));
			/*	for(int i = 0; i < randVec.Length; i++){
					randVec[i] = false;
				}*/
			}
			rand = false;
			STOPIT ++;
			skip = false;
			if(STOPIT > 50000){ //For preventing eternity loop
			//	Debug.Log ("ERROR ERROR ERROR");
				break;
			}
			next = new Vector2(Mathf.RoundToInt(current.x) + direction.x,Mathf.RoundToInt(current.y) + direction.y);
			if(next.x <0 || next.y <0 || next.x >= mLevel.GetLength(0) || next.y >= mLevel.GetLength(1)){ //If outside matrix index
				skip = true;
			}
			if(!skip && !mLevel[(int)next.x,(int)next.y]){ //If ground
				finalPath.Enqueue(next);
				if(next == destination){ //Found destination!
					//Debug.Log("Random Path built!");
					return finalPath;
				}
				current = next;
			} 
			else{ //If wall, randomize new direciton
				int dir = (int)Random.Range(0,8);
			/*	while(randVec[dir]){
					dir = (int)Random.Range(0,8);
				}

				randVec[dir] = true;*/
				direction = convertToDir(dir);
				rand = true;
			}
		}
		//Debug.Log ("Return no path, something went wrong");
		return null;
	}

	Vector2 convertToDir(int dir){
		switch(dir){
		case 0:
			return new Vector2(-1, -1);
		case 1:
			return Vector2.right;
		case 2:
			return Vector2.up;
		case 3:
			return -Vector2.right;
		case 4:
			return -Vector2.up;
		case 5:
			return new Vector2(1, 1);
		case 6:
			return new Vector2(1, -1);
		case 7:
			return new Vector2(-1, 1);
		}
		Debug.Log("convertToDir() in Pathinitializer.cs failed");
		return Vector2.zero;
	}

}

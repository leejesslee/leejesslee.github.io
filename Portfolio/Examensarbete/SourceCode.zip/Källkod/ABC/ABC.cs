﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

public class ABC {

	int mColonySize; //Amount of bees
	int mMaxCycle; //Amount of cycles to run algorithm in
	int mLimit; //Limits for a solution

	PathInitializer mPathIni; //For generating new random paths
	Queue<Vector2>[] mPaths; //= new Queue<Vector2>[mColonySize/2]; //All current paths
	int[] mCounts; //= new int[mColonySize/2]; //Counts for all paths
	int mMaxVal = 0; //Size of longest found path in list of paths
	int mCycle; //Which cycle are we on?
	Queue<Vector2> mFinalPath = new Queue<Vector2> ();
	Stopwatch timer = new Stopwatch ();
	long mPassedTime = 0;

	Vector2 mStart; 
	Vector2 mDest;

	public ABC(Vector2 start, Vector2 dest,bool[,] map, int colonySize, int maxCycle, int limit){
		mColonySize = colonySize;
		mMaxCycle = maxCycle;
		mLimit = limit;
		timer.Reset ();
		timer.Start();
		mPaths = new Queue<Vector2>[mColonySize / 2];
		mCounts = new int[mColonySize / 2];
		mStart = start;
		mDest = dest;
		mPathIni = new PathInitializer (map);
		for (int i = 0; i < mColonySize/2; i++) { //Fills list with paths
			mPaths[i] = mPathIni.buildPath(mStart,mDest); 
			while(mPaths[i] == null){
				mPaths[i] = mPathIni.buildPath(mStart,mDest); 
			}
			mCounts[i] = 0;
			//Debug.Log("No I am totally bulding paths yo");
			if(mPaths[i].Count > mMaxVal){
				mMaxVal = mPaths[i].Count; 
			}
			//Debug.Log("mMaxVal is " + mMaxVal);
		}
		mFinalPath = run ();
		timer.Stop ();
		mPassedTime = timer.ElapsedMilliseconds;
		//UnityEngine.Debug.Log ("Time for ABC is: " + mPassedTime);
	}

	public long getElapsedTime(){
		return mPassedTime;
	}

	Queue<Vector2> run() {
		Queue<Vector2> path2;
		Queue<Vector2> minPath = mPaths [0];
		int index;
		int counter;
		int high;
		mCycle = 0;
		while (mCycle < mMaxCycle) {
			/***********EMPLOYED BEES****************/
			for(int i = 0; i < mPaths.Length; i++){ //Produce neighbor paths
				path2 = modify(mPaths[i]);
				if(mPaths[i].Count > path2.Count){ //Greedy selection
					mPaths[i] = path2;
					mCounts[i] = 0;
				}
				else{
					mCounts[i]++; //If path has not been improved, increase its counter
				}
			}
			/***********EMPLOYED BEES****************/

			/***********ONLOOKER BEES****************/
			for(int i = 0; i < mPaths.Length; i++){
				index = select ();   //Randomly select path
				path2 = modify(mPaths[index]); 
				if(mPaths[index].Count > path2.Count){ //Greedy selection
					mPaths[index] = path2;
					mCounts[index] = 0;
				}
			}
			/***********ONLOOKER BEES****************/

			/***********SCOUT BEES******************/
			counter = mLimit;
			high = -1;
			for(int i = 0; i < mCounts.Length; i++){
				if(mCounts[i] > counter){ //If a path hasn't improved for more tries than limit
					counter = mCounts[i];
					high = i; //Save index
				}
				if(mPaths[i].Count < minPath.Count){ //Checks for shortest path so far
					minPath = mPaths[i];
				}
			}
			if(high > 0){ //If any path has exceeded its limit
				mPaths[high] = mPathIni.buildPath(mStart,mDest); //Turn employed bee into a scout bee
				mCounts[high] = 0; //Reset local counter
				if(mPaths[high].Count < minPath.Count){
					minPath = mPaths[high];
				}
			}
			/***********SCOUT BEES******************/
			mCycle++;
			//Debug.Log ("minPath is" + minPath.Count);
		}
		return minPath;
	}


	int select(){ //Roulette wheel selection, the shorter the path, the higher the chance of it being chosen
		float sum = 0f;
		for (int i = 0; i < mPaths.Length; i++) {
			sum += mMaxVal - mPaths[i].Count;	//Add options to range based on probability
		}
		float value = Random.Range (0f, sum); //Randomize number within range
		float prevValue = 0;
		for (int i = 0; i < mPaths.Length; i++) { //Check which path was chosen
			if(value <= prevValue + (mMaxVal - mPaths[i].Count)){ //Path selected
				//Debug.Log("Roulette selection succeeded");
				return i;
			}	
			else{	//Keep looking for path
				prevValue += mMaxVal - mPaths[i].Count; 
			}
		}
		UnityEngine.Debug.Log ("Roulette Selection failed"); //No path selected
		return -1;
	}

	/*public Queue<Vector2> getModPath(){
		return mCopyModPath;
	}

	public Queue<Vector2> getPath(){
		return mCopyPath;
	}*/

	Queue<Vector2> modify(Queue<Vector2> path){
		Queue<Vector2> copPath = new Queue<Vector2>(path);
		Queue<Vector2> finalPath = new Queue<Vector2>();
		Queue<Vector2> tempPath = new Queue<Vector2> ();
		int from = Random.Range (0,copPath.Count-1); //Pick a random node that isn't the last one in path
		int to = Random.Range (from+1, copPath.Count); //Pick a random node that occurs after start node
		for (int i = 0; i< from; i++) { //Fill path with first unmodified nodes
			finalPath.Enqueue(copPath.Dequeue()); 
		}
		Vector2 fromV = copPath.Dequeue ();
		Vector2 toV = Vector2.zero;
		for (int i= 0; i < to - from; i++) { //Toss away part of path that will be modified and replaced
			toV = copPath.Dequeue();
		}
		if (toV == Vector2.zero) {
			UnityEngine.Debug.Log ("No assigned value to toV"); //ERROR 
			return null;
		}
		tempPath = mPathIni.buildPath (fromV, toV);
		while (tempPath == null) {
			tempPath = mPathIni.buildPath(fromV,toV);
		}
		foreach (Vector2 node in tempPath) { //Fill path with modified part of path
			finalPath.Enqueue(node);
		}
		while (copPath.Count > 0) { //Fill path with remaining unmodified nodes
			finalPath.Enqueue(copPath.Dequeue());
		}
		return finalPath; //Success! 
	}

	public Queue<Vector2> getPath(){
		return mFinalPath;
	}

}

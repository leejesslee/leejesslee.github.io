﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class TestRunner{
	
	Queue<Vector2> mFinalPath;
	int mVal;
	
	public void runTestPar(bool[,] map, int numOfTests,int startVal){
		JObject tempObj; 
		JArray jarray = new JArray();
		mVal = startVal;
		for (int i = 0; i < numOfTests; i++) { 
			ABC abc = new ABC (new Vector2 (1, 1), new Vector2 (40, 40), map,12,7,mVal);
			tempObj = new JObject(
				new JProperty("Limit",mVal),
				new JProperty("Execution time",abc.getElapsedTime()),
				new JProperty("Path size",abc.getPath().Count)
			);
			jarray.Add(tempObj);
			mVal ++;
		}
		string path = @"C:\Users\Jessica\Desktop\Skola\Kurser\Examensarbete\Delinl3\Experimentmiljo\PathfindBee\Assets\Tests\LimitTestStad.txt";
		System.IO.File.WriteAllText(path,jarray.ToString());
		UnityEngine.Debug.Log ("Tests run and finished");
	}

	public void runTestsABC(bool[,] map,int numOfTests,int colony,int cycles,int limit){
		JObject tempObj; 
		JArray jarray = new JArray();
		JObject param = new JObject(
			new JProperty("ColonySize",colony),
			new JProperty("Cycles",cycles),
			new JProperty("Limits",limit)
			);
		jarray.Add (param);
		for (int i = 0; i < numOfTests; i++) { 
			ABC abc = new ABC (new Vector2 (1, 1), new Vector2 (40, 40), map,colony,cycles,limit);
			tempObj = new JObject(
				new JProperty("Execution time",abc.getElapsedTime()),
				new JProperty("Path size",abc.getPath().Count)
				);
			jarray.Add(tempObj);
			mVal ++;
		}
		string path = @"C:\Users\Jessica\Desktop\Skola\Kurser\Examensarbete\Delinl3\Experimentmiljo\PathfindBee\Assets\Tests\ABCTestOppen.txt";
		System.IO.File.WriteAllText(path,jarray.ToString());
		UnityEngine.Debug.Log ("Tests run and finished");
	}

	public void runTestsAStar(bool[,] map,int numOfTests){
		JObject tempObj; 
		JArray jarray = new JArray();
		for (int i = 0; i < numOfTests; i++) { 
			SettlersEngine.AStar astar = new SettlersEngine.AStar(new Vector2(1,1),new Vector2(40,40),map);
			tempObj = new JObject(
				new JProperty("Execution time", astar.getElapsedTime()),
				new JProperty("Path size",astar.getPath().Count)
				);
			jarray.Add(tempObj);
			mVal ++;
		}
		string path = @"C:\Users\Jessica\Desktop\Skola\Kurser\Examensarbete\Delinl3\Experimentmiljo\PathfindBee\Assets\Tests\AstarTestOppen.txt";
		System.IO.File.WriteAllText(path,jarray.ToString());
		UnityEngine.Debug.Log ("Tests run and finished");
	}
	

}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Diagnostics;


public class MapGenerator : MonoBehaviour {

	public GameObject mPrefab;
	public Material mWall;
	public Material mGround;
	public Material mAStarPath;
	public Material mABCPath;
	public Material mModPath;
	public Material mMix;
	public Vector2 mMapSize = new Vector2 (50, 50);
	Vector2 mMousePos;
	bool[,] mTerrains; //false = ground, true = wall
	GameObject[,] mQuads; //graphics for map
	Queue<Vector2> mCopABC = new Queue<Vector2>();
	Queue<Vector2> mCopAStar = new Queue<Vector2>();
	bool mStart = true;
	int mABCLength;
	int mAStarLength;
	Stopwatch timer = new Stopwatch ();

	/******FOR SAVING LEVELS****/
	/*void convert2DToJson(bool[,] map) { 
		JArray jarray = new JArray();
		for (int i = 0; i < map.GetLength(0); i++) {
			JArray tempArr = new JArray();
			for (int j = 0; j < map.GetLength(1); j++) {
				tempArr.Add(new JValue(map[i,j]));
			}
			jarray.Add(tempArr);
		}
		string path = @"C:\Users\Jessica\Desktop\Skola\Kurser\Examensarbete\Delinl3\Experimentmiljo\PathfindBee\Assets\Level6.txt";
		System.IO.File.WriteAllText(path,jarray.ToString());
		UnityEngine.Debug.Log ("Saved level to file");
	}
	*/


	public void convertJsonTo2D(int level) {
		string path = @"Level"+level.ToString()+".txt";
		JArray a = JArray.Parse (System.IO.File.ReadAllText (path));
	
		for (int i = 0; i<mMapSize.x; i++) {
			for (int j = 0; j<mMapSize.y; j++) {
				mTerrains [i, j] = (bool)a[i][j];
				Vector3 pos = new Vector3 (i, j, 0);
				if(mStart){
				mQuads [i, j] = Instantiate (mPrefab, pos,Quaternion.identity)as GameObject;
				}
				if(mTerrains[i,j]){
					mQuads[i,j].GetComponent<MeshRenderer>().material = mWall;
				}
				else{
					mQuads[i,j].GetComponent<MeshRenderer>().material = mGround;
				}
			}
		}
		mStart = false;
	}
	
	// Use this for initialization
	void Start () {
		mQuads = new GameObject[(int)mMapSize.x,(int)mMapSize.y];
		mTerrains = new bool[(int)mMapSize.x, (int)mMapSize.y];
		convertJsonTo2D (7);
	}
	
	// Update is called once per frame
	void Update () {
		/******FOR CREATING LEVELS*****/
		if (Input.GetMouseButtonDown (0)) { 
			mMousePos = new Vector2 (Input.mousePosition.x, Input.mousePosition.y);
			mMousePos = Camera.main.ScreenToWorldPoint (mMousePos);
			if (mMousePos.x < mMapSize.x && mMousePos.x >= 0 && mMousePos.y < mMapSize.y && mMousePos.y >= 0) {
				mMousePos = new Vector2 (Mathf.RoundToInt (mMousePos.x), Mathf.RoundToInt (mMousePos.y));
				bool what = mTerrains [(int)mMousePos.x, (int)mMousePos.y] = !mTerrains [(int)mMousePos.x, (int)mMousePos.y]; //changes bool on click
				mQuads [(int)mMousePos.x, (int)mMousePos.y].GetComponent<MeshRenderer> ().material = what ? mWall : mGround; //changes material according to bool
			} else {
				//UnityEngine.Debug.Log ("Mouse click outside field!");
			}
		}
	}



	/*	if (Input.GetKey (KeyCode.A)) {
			TestRunner tests = new TestRunner ();
			tests.runTests (mTerrains,30,1);
		}*/


	public void pressABC(){
		timer.Reset ();
		mABCLength = 0;
		Vector2 curVec;
		while (mCopABC.Count>0) {
			curVec = mCopABC.Dequeue();
			if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mMix){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mAStarPath;
			}
			else if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mABCPath){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mGround;
			}
		}
		timer.Start ();
		ABC abc = new ABC(new Vector2(1,1),new Vector2(40,40),mTerrains,16,22,12);
		timer.Stop ();
		Queue<Vector2> finalPath = new Queue<Vector2>(abc.getPath());
		mABCLength = finalPath.Count;
		while(finalPath.Count>0){
			//mABCLength++;
			curVec = finalPath.Dequeue();
			mCopABC.Enqueue(curVec);
			if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mAStarPath){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mMix;
			}
			else{
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mABCPath;
			}
		}
		//UnityEngine.Debug.Log ("ABC returned a path of length " + mABCLength);
		//UnityEngine.Debug.Log ("Time elapsed for ABC: " + timer.ElapsedMilliseconds);
	}

	public void pressAStar(){
		timer.Reset ();
		mAStarLength = 0;
		Vector2 curVec;
		while (mCopAStar.Count>0) {
			curVec = mCopAStar.Dequeue();
			if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mMix){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mABCPath;
			}
			else if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mAStarPath){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mGround;
			}
		}
		timer.Start ();
		SettlersEngine.AStar astar = new SettlersEngine.AStar (new Vector2 (1, 1), new Vector2 (40, 40), mTerrains);
		timer.Stop ();
		Queue<Vector2> finalPath = new Queue<Vector2>(astar.getPath());
		mAStarLength = finalPath.Count;
		while (finalPath.Count>0) {
			//mAStarLength++;
			curVec = finalPath.Dequeue ();
			mCopAStar.Enqueue(curVec);
			if(mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().sharedMaterial == mABCPath){
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mMix;
			}
			else{
				mQuads [(int)curVec.x, (int)curVec.y].GetComponent<MeshRenderer> ().material = mAStarPath;
			}
		}
		//UnityEngine.Debug.Log ("A* returned a path of length " + mAStarLength); 
		//UnityEngine.Debug.Log ("Time elapsed for AStar: " + timer.ElapsedMilliseconds);
	}

	bool[,] getMap(){ //Might not be neccessary
		return mTerrains;
	}
}

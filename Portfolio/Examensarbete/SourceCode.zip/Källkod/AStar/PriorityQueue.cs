﻿using UnityEngine;
using System;
using System.Collections.Generic;

public class PriorityQueue<T> where T : IComparer<Node>{

	List<Node> data;
	
	public PriorityQueue() {
		this.data = new List<Node>();
	}
	
	public void enqueue(Node item) {
		data.Add(item);
		int i = data.Count - 1; // start at end
		while (i > 0) {
			int j = (i - 1) / 2; // parent index
			if (data[i].getF().CompareTo(data[j].getF()) >= 0)// child item is larger than or equal to parent 
				break; 
			Node temp = data[i];
			data[i] = data[j];
			data[j] = temp;
			i = j;
		}
	}

	public Node dequeue() {
		int last = data.Count - 1; // last element
		Node frontItem = data[0];   // save the front
		data[0] = data[last];
		data.RemoveAt(last);

		last--; // last new index 
		int i = 0; // parent index
		while (true) {
			int j = i * 2 + 1; // left child index of parent
			if (j > last) // no children 
				break;  
			int rc = j + 1;     // right child
			if (rc <= last && data[rc].getF().CompareTo(data[j].getF()) < 0) // if there is a rc and it's smaller than left child
				j = rc; //use rc instead
			if (data[i].getF().CompareTo(data[j].getF()) <= 0)
				break; // parent is smaller than (or equal to) smallest child so done
			Node temp = data[i];
			data[i] = data[j];
			data[j] = temp; // swap parent and child
			i = j;
		}
		return frontItem;
	}

	public Node peek() {
		Node frontItem = data[0];
		return frontItem;
	}
	
	public Node peekAt(int index) {
		Node frontItem = data[index];
		return frontItem;
	}
	
	public void replaceAt(int index, Node element) {
		data[index] = element;
		float temp = element.getF();
		int i = index;
		if (index < data.Count - 1 && temp > data [index + 1].getF()) {
			for (i = index; i < data.Count-1 && data[i+1].getF() <= temp; i++)
				data [i] = data [i + 1];
		} else {
			if(index >0){
				for (i = index; i > 0 && data[i-1].getF() >= temp; i--)
					data [i] = data [i - 1];
			}
		}
		data[i] = element;
	}
	
	public int count() {
		return data.Count;
	}
}
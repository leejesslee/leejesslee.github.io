﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Node : IComparer<Node>{
	
	float mH;
	float mF;
	float mG;
	int mXPos;
	int mYPos;
	Node mParent;
	
	public Node(int thisPosX,int thisPosY, Vector2 goalPos, Node parent){
		mXPos = thisPosX;
		mYPos = thisPosY;
		if (parent == null) {
			mG = 0;	
		} else {
			mG = parent.getG () + 1;
		}
		calculateH (thisPosX,thisPosY, goalPos);
		mF = mH + mG;
		mParent = parent;
	}


	
	void calculateH(int thisPosX,int thisPosY, Vector2 goalPos){
		mH = Vector2.Distance (new Vector2 (thisPosX, thisPosY), goalPos);
	}
	
	public float getF(){
		return mF;
	}
	
	public float getG(){
		return mG;
	}
	
	public int getXPos(){
		return mXPos;
	}
	public int getYPos(){
		return mYPos;
	}
	
	public Node getParent(){
		return mParent;
	}

	public int Compare(Node n1, Node n2)
	{
		return n2.getF().CompareTo(n1.getF());
	}
}

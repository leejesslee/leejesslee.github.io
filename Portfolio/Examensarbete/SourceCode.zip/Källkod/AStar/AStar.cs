﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace SettlersEngine{

	public class AStar {

		bool[,] mMap; 
		//List<Node> mOpen = new List<Node>();
		long mElapsedTime;
		List<Node> mClosed = new List<Node>();
		Node mCurrent;
		Vector2 mDestination;
		Queue<Vector2> mFinalPath = new Queue<Vector2> ();
		Stopwatch timer = new Stopwatch();
		PriorityQueue<Node> mOpen = new PriorityQueue<Node> ();

		public AStar (Vector2 startPos, Vector2 destPos, bool[,] map) {
			timer.Reset ();
			timer.Start();
			mMap = map;
			mDestination = destPos;
			Node start = new Node ((int)startPos.x, (int)startPos.y, destPos, null);
			mOpen.enqueue (start);
			//mOpen.Add (start);
			mFinalPath = run ();
			timer.Stop ();
			mElapsedTime = timer.ElapsedMilliseconds;
			//UnityEngine.Debug.Log ("Time for Astar is: " + timer.ElapsedMilliseconds);
		}

		public Queue<Vector2> getPath(){
			return mFinalPath;
		}

		public long getElapsedTime(){
			return mElapsedTime;
		}

		Queue<Vector2> buildPath(Node lastNode){
			Stack<Vector2> sFinalPath = new Stack<Vector2> ();
			Queue<Vector2> qFinalPath = new Queue<Vector2> ();
			int STOPIT1 = 0;
			int STOPIT2 = 0;
			Node parent = lastNode;
			while(true){
				STOPIT1 ++;
				if(STOPIT1 > 100000){ //For preventing eternity loop
					UnityEngine.Debug.Log ("ERROR ERROR ERROR");
					break;
				}
				if(parent == null){
					break;
				}
				else{
					sFinalPath.Push(new Vector2(parent.getYPos(),parent.getXPos()));
					parent = parent.getParent();
				}
			}
			while(sFinalPath.Count > 0) {
				STOPIT2 ++;
				if(STOPIT2 > 100000){ //For preventing eternity loop
					UnityEngine.Debug.Log ("ERROR ERROR ERROR");
					break;
				}
				qFinalPath.Enqueue(sFinalPath.Pop());
			}
			return qFinalPath;
		}

		// Update is called once per frame
		Queue<Vector2> run() {
			int STOPIT = 0;
			Vector2 direction;
			bool skip = false;
			bool inList = false;
			Node successor;
			while (mOpen.count() > 0) {
				STOPIT ++;
				if(STOPIT > 100000){ //For preventing eternity loop
					UnityEngine.Debug.Log ("ERROR ERROR ERROR");
					break;
				}
		      	//mOpen.Sort(new NodeSorter());
				mCurrent = mOpen.dequeue();
				//mCurrent = mOpen[mOpen.Count-1];
				//mOpen.RemoveAt(mOpen.Count-1);
				mClosed.Add(mCurrent);
				if(mCurrent.getXPos() == (int)mDestination.x && mCurrent.getYPos() == (int)mDestination.y){ //Destination found!
					while(mOpen.count() > 0){
					mOpen.dequeue();
					}
					return buildPath(mCurrent);
				}
				for(int i = 0; i < 8; i++){ //Check all neighbors
					skip = false;
					inList = false;
					direction = convertToDir(i);
					Vector2 next = new Vector2(mCurrent.getXPos() + (int)direction.x,mCurrent.getYPos() + (int)direction.y);
					foreach(Node node in mClosed){ //If node is in closed list
						if(node.getXPos() == (int)next.x && node.getYPos() == (int)next.y){
							skip = true;
						}
					}
					if(!skip && next.x < 0 || next.y < 0 || next.x >= mMap.GetLength(0) || next.y >= mMap.GetLength(1)){ //If node is out of range of array
						skip = true;
					}
					if(!skip && mMap[(int)next.y,(int)next.x] == false){ //If ground
						successor = new Node((int)next.x,(int)next.y,mDestination,mCurrent);
						for(int j = 0; j < mOpen.count(); j++){
							if(mOpen.peekAt(j).getXPos() == successor.getXPos() && mOpen.peekAt(j).getYPos() == successor.getYPos()){ //If successor is already in mOpen
								inList = true;
								if(mOpen.peekAt(j).getG() > successor.getG()){ //If successor's G is better, replace with it
										mOpen.replaceAt(j,successor);
								}
							}
						}
						if(!inList){ //If successor is not in mOpen
							mOpen.enqueue(successor);
						}
					}
				}
			}
			UnityEngine.Debug.Log ("Astar failed");
			return null;
		}

		Vector2 convertToDir(int i){
			switch(i){
			case 0:
				return  Vector2.right;
			case 1:
				return new Vector2(1, -1);
			case 2:
				return -Vector2.up;
			case 3:
				return new Vector2(-1, -1);
			case 4:
				return -Vector2.right;
			case 5:
				return new Vector2(-1, 1);
			case 6:
				return Vector2.up;
			case 7:
				return new Vector2(1, 1);
			}
			UnityEngine.Debug.Log("convertToDir() in AStar.cs failed");
			return Vector2.zero;
		}
	}
}

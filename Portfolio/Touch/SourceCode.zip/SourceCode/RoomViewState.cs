﻿using UnityEngine;
using System.Collections;

public class RoomViewState : CameraState {

	public float _SwipeSpeed = 0.1f;
	public float _LerpSpeedd = 1;
	public float _LerpLength = 1;
	Vector2 _swipePos = Vector2.zero;
	
	public override void Enter(){
		EasyTouch.On_Drag += OnDrag; 
		EasyTouch.On_Swipe += OnSwipe;
	}
	
	public override void Exit(){
		EasyTouch.On_Drag -= OnDrag; 
		EasyTouch.On_Swipe -= OnSwipe;
	}
	
	public override void update () {
	}

	void OnDrag(Gesture gesture){ //Rotates camera when swiping occurs, will probably need some lerp to look smoother
		_swipePos = gesture.deltaPosition;
		transform.Rotate(0, -_swipePos.x*_SwipeSpeed, 0); 
	}

	void OnSwipe(Gesture gesture){ //Rotates camera when swiping occurs, will probably need some lerp to look smoother
		_swipePos = gesture.deltaPosition;
		transform.Rotate(0, -_swipePos.x*_SwipeSpeed, 0); 
	}

    public void zoomOut() {
        SendMessage("switchState", 4);
    }

    public void switchToZoom (GameObject target){
		SendMessage ("UpdateTarget", target);
		SendMessage ("switchState", 2); //Switch to ZoomIn state if double tap
	}
}

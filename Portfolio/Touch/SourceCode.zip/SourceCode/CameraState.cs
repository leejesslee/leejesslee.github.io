﻿using UnityEngine;
using System.Collections;

public class CameraState : MonoBehaviour {

	// Use this for initialization
	public CameraState(){
	
	}

	public virtual void Enter(){
		
	}

	public virtual void Exit(){
		
	}

	public virtual void update () {
	
	}
}

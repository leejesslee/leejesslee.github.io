﻿using UnityEngine;
using System.Collections;

public class ZoomState : CameraState {

	public float _SwipeSpeed = 0.01f; //Swipe sensitivity
	public float _cameraBoundsX = 3; //Higher value -> smaller boundary area
	public float _cameraBoundsY = 6; //Higher value -> smaller boundary area
	public float _snapSpeed = 0.2f; //How fast camera snaps back when outside boundary in seconds
	
	Vector2 _swipePos = Vector2.zero;
	Vector3 _cameraStartPos = Vector3.zero;
	float _camHeight;
	float _camWidth; 

	public override void Enter(){
		_cameraStartPos = transform.position;
		_camHeight = Camera.main.orthographicSize * 2.0f;
		_camWidth = _camHeight * Screen.width / Screen.height;

		/*Functions activated by EasyTouch*/
		EasyTouch.On_Drag += OnDrag; 
		EasyTouch.On_Swipe += OnSwipe; 
		EasyTouch.On_DragEnd += OnDragEnd;
		EasyTouch.On_SwipeEnd += OnSwipeEnd;
	}
	
	public override void Exit(){
		EasyTouch.On_Drag -= OnDrag; 
		EasyTouch.On_Swipe -= OnSwipe;
		EasyTouch.On_DragEnd -= OnDragEnd;
		EasyTouch.On_SwipeEnd -= OnSwipeEnd;
	}
	
	public override void update () {

	}

	void OnDrag(Gesture gesture){ //Rotates camera when swiping occurs
		_swipePos = gesture.deltaPosition;
		if (Mathf.Abs (_swipePos.x) > Mathf.Abs (_swipePos.y)) { 
			transform.position += transform.TransformDirection(new Vector3(-_swipePos.x*_SwipeSpeed,0f,0f)); //Horizontal swipe
		} else {
			transform.position += transform.TransformDirection(new Vector3(0f,-_swipePos.y*_SwipeSpeed,0f)); //Vertical swipe
		}
	}

	void OnSwipe(Gesture gesture){ //Rotates camera when swiping occurs
		_swipePos = gesture.deltaPosition;
		if (Mathf.Abs (_swipePos.x) > Mathf.Abs (_swipePos.y)) {
			transform.position += transform.TransformDirection(new Vector3(-_swipePos.x*_SwipeSpeed,0f,0f)); //Horizontal swipe
		} else {
			transform.position += transform.TransformDirection(new Vector3(0f,-_swipePos.y*_SwipeSpeed,0f)); //Vertical swipe
		}
	}

	void OnDragEnd(Gesture gesture){
		if (transform.InverseTransformPoint(_cameraStartPos).x <= -(_camWidth/_cameraBoundsX)){ //If outside right boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(_camWidth / (_cameraBoundsX+1),-transform.InverseTransformPoint(_cameraStartPos).y,0f); 
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).x >= (_camWidth/_cameraBoundsX)){ //If outside left boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-(_camWidth / (_cameraBoundsX+1)),-transform.InverseTransformPoint(_cameraStartPos).y,0f); 
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).y >= (_camHeight/6)){ //If outside bottom boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-transform.InverseTransformPoint(_cameraStartPos).x,-(_camHeight / (_cameraBoundsY+1)),0f);
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).y <= -(_camHeight/6)){ //If outside upper boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-transform.InverseTransformPoint(_cameraStartPos).x,(_camHeight / (_cameraBoundsY+1)),0f);
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
	}

	void OnSwipeEnd(Gesture gesture){
		if (transform.InverseTransformPoint(_cameraStartPos).x <= -(_camWidth/_cameraBoundsX)){ //If outside right boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(_camWidth / (_cameraBoundsX+1),-transform.InverseTransformPoint(_cameraStartPos).y,0f); 
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).x >= (_camWidth/_cameraBoundsX)){ //If outside left boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-(_camWidth / (_cameraBoundsX+1)),-transform.InverseTransformPoint(_cameraStartPos).y,0f); 
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).y >= (_camHeight/6)){ //If outside bottom boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-transform.InverseTransformPoint(_cameraStartPos).x,-(_camHeight / (_cameraBoundsY+1)),0f);
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
		if (transform.InverseTransformPoint(_cameraStartPos).y <= -(_camHeight/6)){ //If outside upper boundary
			Vector3 boundPos = _cameraStartPos + transform.TransformDirection(-transform.InverseTransformPoint(_cameraStartPos).x,(_camHeight / (_cameraBoundsY+1)),0f);
			StartCoroutine(snapBack(transform.position, boundPos, _snapSpeed));
		}
	}

	IEnumerator snapBack(Vector3 startPos, Vector3 dest, float time){ //Snaps camera back inside its boundary
		float elapsedTime = 0;
		while (elapsedTime < time){
			transform.position = Vector3.Lerp(startPos, dest, (elapsedTime/time));
			elapsedTime += Time.deltaTime;
			yield return null;
		}
	}
}
﻿using UnityEngine;
using System.Collections;

public class CameraStateMachine : MonoBehaviour {

	//All available states, feel free to add new ones, remember to add a new CameraState  
		//variable for the state and to add it to switchState function as well
	public enum State{
		zeroenum, //Because sendmessage is stupid
		Roomview, //1
		Zoomin, //2
		Zoomed, //3
		Zoomout //4
	}
	/**States**/
	CameraState _roomView;
	CameraState _zoomIn;
	CameraState _zoomed;
	CameraState _zoomOut;
	/**States**/

	CameraState _startState;
	CameraState _currentState;
    private State _currentEnumState;

	public State CurrentEnumState{
        get { return _currentEnumState; }
	}

	// Use this for initialization
	void Start () {
		_roomView = GetComponent<RoomViewState> ();
		_zoomIn = GetComponent<ZoomInState> ();
		_zoomed = GetComponent<ZoomState> ();
		_zoomOut = GetComponent<ZoomOutState> ();
		_startState = _roomView;
		_currentState = _startState;
        _currentEnumState = State.Roomview;
		_currentState.Enter();
	}

	// Update is called once per frame
	void Update () {
		_currentState.update();
	}

	//For switching states, all states must be included
	public void switchState(State state){ 
		_currentState.Exit();
		switch (state) {
		case State.Roomview:
			_currentState = _roomView;
			_currentState.Enter();
			break;
		case State.Zoomin:
			_currentState = _zoomIn;
			_currentState.Enter();
			break;
		case State.Zoomed:
			_currentState = _zoomed;
			_currentState.Enter();
			break;
		case State.Zoomout:
			_currentState = _zoomOut;
			_currentState.Enter();
			break;
		}
	    _currentEnumState = state;
	}
}

﻿using UnityEngine;
using System.Collections;

public class JumpingMan : MonoBehaviour {

	private Animator _animator;
	private CharacterController _charCon;
	private Vector3 _jumpingMove = Vector3.zero;
	private float _clock;
	public float _maxTime = 1f;
	private bool _jump = false;
	private float _stickLength;
	private float _mrHigh = 0;

	public bool _dead = false;
	public float _maxFallHigh = 5;
	public float _gravity = 20.0f;
	public float _jumpHeight = 10.0f;
	[Range(0.01f, 2.0f)]
	public float _speedScale = 1.0f;
	public float _rayLength = 1.0f;
	[Range(0, 25)]
	public float _jumpOffsetDistanceFuckers = 13;


	RaycastHit _rayHit;

	public float _slidingAngle = 45;
	public float _fallingAngle = 70;
	[Range(0.0f, 1.0f)]
	public float _slidingFactor = 0.625f;


	private GameObject _camera;
	private Vector3 _airVelocity = Vector3.zero;
	public float _MAX_AIRSPEED = 4.8f;

	// Use this for initialization
	void Start () {
		_animator = GetComponent<Animator>();
		_charCon = GetComponent<CharacterController> ();
		_camera = GameObject.FindGameObjectWithTag("MainCamera");
	}
	
	// Update is called once per frame
	void Update () {

		_stickLength = (Mathf.Abs (Input.GetAxis ("Horizontal")) + Mathf.Abs (Input.GetAxis ("Vertical")));

		if(Camera.main.GetComponent<ThirdPersonCamera>().camState != ThirdPersonCamera.CamStates.Focus) {
        if (Input.GetButtonDown("Jump") && (_animator.GetCurrentAnimatorStateInfo(0).IsName("Run") || _animator.GetCurrentAnimatorStateInfo(0).IsName("Idle"))){	//Aktiverar hoppet
			if(!_jump){


				if(_stickLength != 0){
					_jumpingMove.x = transform.forward.x * _MAX_AIRSPEED;
					_jumpingMove.z = transform.forward.z * _MAX_AIRSPEED;
					_jumpingMove *= Mathf.Clamp(_stickLength,0, 1);
					_animator.SetBool("Jump", true);
				}else{
					_jumpingMove = Vector3.zero;
					_animator.SetBool("Jump", true);
				}
					

				_jumpingMove.y = _jumpHeight;
				_animator.applyRootMotion = false;
				_animator.SetBool("Jump", true);
				_clock = Time.time;


				_airVelocity = Vector3.zero;

			}

		}
		}
		if(!_jump && Physics.SphereCast(transform.position + new Vector3(0,1,0), 0.3f ,Vector3.down,out _rayHit,2.5f)){
			if(Physics.SphereCast(transform.position + new Vector3(0,1,0), 0.3f /*+ _offsetY*/ ,Vector3.down,out _rayHit, _rayLength)){
				if(Vector3.Angle(Vector3.up, _rayHit.normal) < _slidingAngle){
					_animator.SetBool("Falling", false);
					_mrHigh = transform.position.y;

					if(Time.time - _clock > _maxTime){
						_jumpingMove = Vector3.zero;
					}
				}else{
					Vector3 slide_vec = Vector3.RotateTowards(_rayHit.normal, Vector3.down, Mathf.PI/2.0f, 0).normalized;
					slide_vec *= _gravity*-slide_vec.y*Time.deltaTime*_slidingFactor;
					_charCon.Move(slide_vec);
				}
			}else{
				_jumpingMove.y -= _gravity*Time.deltaTime;
				_charCon.Move(_jumpingMove*Time.deltaTime);
			}
		} else{
			_animator.SetBool("Falling", true);

			_jumpingMove.y -= _gravity*Time.deltaTime;
			_charCon.Move(_jumpingMove*Time.deltaTime);
		}

		////If characters falls from to high pos he dies.
		if(_mrHigh - transform.position.y >= _maxFallHigh){
			_dead = true;
			_mrHigh = transform.position.y;
		}


		////Handles the jump, how to move through the air when not grounded, how the gravity is handled and that controlling the character is based from the camera.
		if(_jump){

			if(Vector3.Angle(Vector3.up, _rayHit.normal) < _slidingAngle){
				Vector3 jumpForwardVec = new Vector3(_camera.transform.forward.x, 0, _camera.transform.forward.z).normalized * _jumpOffsetDistanceFuckers * Input.GetAxis ("Vertical") * Time.deltaTime;
				Vector3 jumpRightVec = new Vector3(_camera.transform.right.x, 0, _camera.transform.right.z).normalized * _jumpOffsetDistanceFuckers * Input.GetAxis ("Horizontal") * Time.deltaTime;

				_airVelocity = jumpRightVec + jumpForwardVec;
				_jumpingMove.x += _airVelocity.x;
				_jumpingMove.z += _airVelocity.z;

				Vector2 _currentAirSpeed = new Vector2(_jumpingMove.x, _jumpingMove.z);


				////checks if the current speed in x- and z- axis while airborn. If it's to high, it sets to max.
				if(_currentAirSpeed.sqrMagnitude > _MAX_AIRSPEED *_MAX_AIRSPEED){
					_currentAirSpeed.Normalize();
					_currentAirSpeed *= _MAX_AIRSPEED;

					_jumpingMove.x = _currentAirSpeed.x;
					_jumpingMove.z = _currentAirSpeed.y;
				}
			}

			////Waits for a while before doing the raycast to check if character is touching ground.
			if(Time.time - _clock > _maxTime){
				if(Physics.SphereCast(transform.position + new Vector3(0,1,0), 0.3f /*+ temp.y*/ ,Vector3.down,out _rayHit, _rayLength)){	//Nuddat marken och kan hoppa igen
					if(!_rayHit.collider.name.Equals(this.name)){
						_animator.SetBool("Jump", false);

						////Checks angle between ground and ground. If to high, the char slides until touching a flat enough surface
						if(Vector3.Angle(Vector3.up, _rayHit.normal) < _slidingAngle){

							_animator.SetBool("Falling", false);
							_jumpingMove = Vector3.zero;
							_jump = false;
							_animator.applyRootMotion = true;
						}else{

							if(Vector3.Angle(Vector3.up, _rayHit.normal) < _fallingAngle){
								_animator.SetBool("Falling", false);
								_jumpingMove = Vector3.zero;
							}

							_animator.SetBool("Jump", false);
							
							Vector3 slide_vec = Vector3.RotateTowards(_rayHit.normal, Vector3.down, Mathf.PI/2.0f, 0).normalized;
							slide_vec *=  _gravity*-slide_vec.y*Time.deltaTime*_slidingFactor;
							_charCon.Move(slide_vec);

						}
					}
				}
			}
		}
	}


	public bool isJumping(){
		return _jump;
	}

	public void Jumpy(){
		_jump = true;

	}

	public void setDead(bool status){
		_dead = status;
	}

}

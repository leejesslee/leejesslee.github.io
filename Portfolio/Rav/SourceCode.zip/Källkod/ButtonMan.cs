﻿using UnityEngine;
using System.Collections;

public class ButtonMan : MonoBehaviour {

//	Button _button;
	bool _pressedMode = false;
	
	// Update is called once per frame
	void Update () {
	
	}

	void ButtonPressed(){
		_pressedMode = true;
	}

	public bool isPressed(){
		return _pressedMode;
	}

	public void setPressed(bool ispressed){
		_pressedMode = ispressed;
	}
}

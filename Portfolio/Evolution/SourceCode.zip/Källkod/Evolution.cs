﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Evolution : MonoBehaviour {

	Population childPopulation;
	Population population;
	Interface inter;
	bool clicked = false;
	Color primary;
	List<Color> primaries = new List<Color>();

	// Use this for initialization
	void Start () {
		inter = GetComponent<Interface> ();
		population = new Population ();
		childPopulation = new Population();
	}
	
	// Update is called once per frame
	void Update () {
		if (inter.isClicked()) { //Checks if Interface received input
			inter.setClicked(false);
			primary = inter.getPrimary();
			primaries.Add (primary);
			evolve(buildPopulation(inter.getColors()));
		}
	}

	void evolve(Population pop){
		while (childPopulation.population.Count < 6) {
			Color genome0 = select (pop);
			Color genome1 = select (pop);
			Population.tuple temp = new Population.tuple(combine(genome0,genome1),0f);
			childPopulation.add (temp.mGenome,temp.mFitness);
		}
		inter.refresh (childPopulation);
		population.population.Clear();
		childPopulation.population.Clear ();
	}

	Population buildPopulation(List<Color> colors){
		foreach (Color color in colors) {
			population.add (color,evaluate(color));
		}
		foreach (Color color in primaries) {
			population.add (color,evaluate (color));		
		}
		return population;
	}

	float evaluate(Color col){ //Sets a color's fitness value
		float fitness = 3 - Mathf.Abs (((primary.r - col.r) + (primary.g - col.g) + (primary.b - col.b)));
		return fitness;
	}

	Color select(Population pop){ //Roulette selection
		float prevValue= 0;
		float sum = 0;
		foreach (Population.tuple tuple in pop.population) {
			sum += tuple.mFitness;
		}
		float value = Random.Range (0f, sum);
		foreach (Population.tuple tuple in pop.population) {
			if(value <= prevValue + tuple.mFitness){
				return tuple.mGenome;
			}
			prevValue = prevValue + tuple.mFitness;
		}
		Debug.Log ("Random generation failed");
		return Color.white;
	}

	Color combine(Color genome0, Color genome1){ //Arithmetic crossover
		Color color = new Color((genome0.r + genome1.r) / 2, 
		                        (genome0.g + genome1.g) / 2, 
		                        (genome0.b + genome1.b) / 2);
		for (int i = 0; i<3; i++) {	//Mutation
			if(Random.Range(0f,1f) <= 0.05f){ // 5% chance 
				color[i] = Random.Range(0f,1f);
			}		
		}
		return color;
	}
}

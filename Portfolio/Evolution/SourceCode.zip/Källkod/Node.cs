﻿using UnityEngine;
using System.Collections;

public class Node : MonoBehaviour {

	float mCost; 

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void addCost(Vector2 startPos,Vector2 thisPos){
		mCost = thisPos.x - startPos.x;
	}

	public float getCost(){
		return mCost;
	}
}

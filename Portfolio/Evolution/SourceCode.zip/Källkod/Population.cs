﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Population : MonoBehaviour {

	public List<tuple> population = new List<tuple>();
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public struct tuple{
		public Color mGenome;
		public float mFitness;
		public tuple(Color genome,float fitness){
			mGenome = genome;
			mFitness = fitness;
		}
	}

	public void add(Color genome, float fitness){
		population.Add (new tuple (genome, fitness));
	}
}

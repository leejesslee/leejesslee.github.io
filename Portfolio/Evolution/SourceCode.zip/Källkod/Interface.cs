﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Interface : MonoBehaviour {

	public Rect size = new Rect(100,100,100,100);
	Rect CopySize;
	List<Color> colors = new List<Color> ();
	List<Texture2D> textures = new List<Texture2D>();
	Color primary;
	bool buttonClicked = false;
	public GUIStyle test;

	// Use this for initialization
	void Start () {
		CopySize = size;
		for(int i = 0; i<6; i++){ //Random generating first colors
			float r = Random.Range(0,100)/100f;
			float g = Random.Range(0,100)/100f;
			float b = Random.Range(0,100)/100f;
			colors.Add (new Color(r,g,b));
			Texture2D temp = new Texture2D(1,1);
			temp.SetPixel(0,0,new Color(r,g,b));
			temp.Apply();
			textures.Add (temp);
		}
	}

	// Update is called once per frame
	void Update () {

	}

	void OnGUI(){
		size = CopySize;
		foreach(Texture2D texture in textures){ //Drawing everything
			Rect textRect = new Rect(size.position.x, size.position.y + 20,size.width,size.height);
			GUI.DrawTexture (textRect,texture,ScaleMode.StretchToFill);
			GUI.Label(size, ColorToHex(texture.GetPixel(1,1)));
			if(GUI.Button(size,texture,GUIStyle.none)){ //Input
				primary = texture.GetPixel (1,1);
				buttonClicked = true;
			}
			Rect tempRect = new Rect(size.position.x +size.width,size.position.y,size.width,size.height);	
			size = tempRect;
		}
	}

	public void refresh(Population pop){ //Called when Evolution is finished
		textures.Clear ();
		colors.Clear ();
		for(int i = 0;i < pop.population.Count; i++){
			colors.Add (pop.population[i].mGenome);
			Texture2D temp = new Texture2D(1,1);
			temp.SetPixel(0,0,pop.population[i].mGenome);
			temp.Apply();
			textures.Add (temp);
		}
	}

	public bool isClicked(){
		return buttonClicked;
	}

	public void setClicked(bool isClicked){
		buttonClicked = isClicked;
	}

	public Color getPrimary(){
		return primary;
	}

	public List<Color> getColors(){
		return colors;
	}

	string ColorToHex(Color32 color){
				string hex = color.r.ToString ("X2") + color.g.ToString ("X2") + color.b.ToString ("X2");
				return hex;
	}
}
